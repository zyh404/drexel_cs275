There is panel, if you click the menue and it will show you three button, Home Database Table and Transcript student. 
You can click those three button, and go to different page. In the database table button, you will can select course grade and student 
those three option in drop down, and it will show the database table in the page based on the sql we made.
In the transcript student button, you can select each students name and term he took, it will just show you all of database table 
as you want.